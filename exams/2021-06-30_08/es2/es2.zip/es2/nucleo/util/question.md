Definiamo una "msg-area" come una zona della memoria fisica accessibile
tramite indirizzi della parte utente/privata di un processo. Tutte le
msg-area hanno una dimensione costante pari a `MSG_AREA_PAGES` pagine.
Ogni msg-area, in ogni istante, è accessibile da un solo processo, e
ciascun processo può accedere al più ad una msg-area per volta (dunque
anche nessuna). Se un processo può accedere ad una msg-area $m$ diciamo
che è l'*owner* (temporaneo) di $m$. Un processo che non sia già owner
di una msg-area può crearne una nuova tramite la primitiva `macreate()`,
che ne restituisce un puntatore alla base. Un processo $P_1$ che è owner
di una msg-area $m$ può *spedirla* a un processo diverso $P_2$, purché
questo non sia già owner di un'altra msg-area. Dopo la spedizione, $P_2$
diventa il nuovo owner di $m$ e vi può accedere liberamente in lettura e
scrittura, mentre $P_1$ non è più l'owner e non può più accedervi.

Per realizzare il meccanismo precedente aggiungiamo ai descrittori di
processo il campo `bool maowner`, che vale `true` se e solo se il
processo è owner di una msg-area. Introduciamo inoltre le seguenti
primitive (abortiscono il processo in caso di errore):

-   `void* macreate()` (già realizzata): crea una nuova msg-area e
    restitutisce un puntatore alla base, o `nullptr` se non è stato
    possibile crearla. È un errore se il processo che invoca la
    primitiva è già owner di un'altra msg-area.

-   `bool masend(natl pid)` (da realizzare): spedisce la msg-area del
    processo corrente al processo `pid`; restituisce `false` se il
    processo `pid` non esiste, oppure è già owner di un'altra msg-area,
    oppure se non è stato possibile eseguire il trasferimento, per
    esempio per esaurimento della memoria. In tutti questi casi la
    primitiva deve lasciare la situazione corrente inalterata. È un
    errore se la primitiva viene invocata da un processo che non è owner
    di una msg-area, oppure se un processo tenta di inviare la msg-area
    a se stesso o a un processo di livello sistema.

Modificare il file `sistema.cpp` in modo da realizzare la primitiva
mancante.
