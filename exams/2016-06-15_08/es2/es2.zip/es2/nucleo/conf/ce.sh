QEMU_EXTRA_OPTIONS="-chardev pipe,id=ce1a,path=ce1a -device ce,id=ce1,async=ce1a"
QEMU_PRE_CMD="perl ce1.pl &"
QEMU_FIFOS="ce1a ce1"

